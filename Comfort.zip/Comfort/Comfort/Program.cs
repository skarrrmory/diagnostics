using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace Comfort
{
    // Класс содержит метод Main для запуска приложения
    internal static class Program
    {
        // Флаг доступности подключения к базе данных
        public static bool DbAvailable { get; private set; }

        // Точка входа: настраивает стили и запускает главное окно
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            // Проверяем подключение к БД
            try
            {
                var connStr = ConfigurationManager.ConnectionStrings["ComfortDB"].ConnectionString;
                using (var conn = new SqlConnection(connStr))
                {
                    conn.Open();
                    DbAvailable = true;
                }
            }
            catch
            {
                DbAvailable = false;
                MessageBox.Show("Не удалось установить соединение с базой данных. Приложение будет работать без данных.",
                    "Ошибка подключения", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            Application.Run(new Form1());
        }
    }
}

