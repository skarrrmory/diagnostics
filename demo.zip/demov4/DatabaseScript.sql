-- Создание базы данных для системы управления продукцией мебельной компании "Комфорт"
-- Скрипт создан на основе данных из Excel файлов

USE master;
GO

-- Создание базы данных
IF EXISTS (SELECT name FROM sys.databases WHERE name = 'FurnitureCompanyDB')
    DROP DATABASE FurnitureCompanyDB;
GO

CREATE DATABASE FurnitureCompanyDB;
GO

USE FurnitureCompanyDB;
GO

-- Таблица типов продукции
-- Таблица типов продукции
-- Таблица типов продукции
CREATE TABLE TypeProducts (
    TDTypeProduct INT IDENTITY(1,1) PRIMARY KEY,
    TypeName VARCHAR(50) NOT NULL,
    TypeCoefficient DECIMAL(5,2) NOT NULL
);

-- Таблица типов материалов
CREATE TABLE TypeMaterial (
    IDTypeMaterial INT IDENTITY(1,1) PRIMARY KEY,
    MaterialName VARCHAR(50) NOT NULL,
    ProssentLosses DECIMAL(5,2) NOT NULL
);

-- Таблица цехов
CREATE TABLE Workshops (
    IDWorkshop INT IDENTITY(1,1) PRIMARY KEY,
    WorkshopName VARCHAR(100) NOT NULL,
    WorkshopType VARCHAR(50) NOT NULL,
    PeopleCount INT NOT NULL
);

-- Таблица продукции
CREATE TABLE Products (
    IDProducts INT IDENTITY(1,1) PRIMARY KEY,
    ProductName VARCHAR(100) NOT NULL,
    IDTypeProduct INT NOT NULL,
    IDTypeMaterial INT NOT NULL,
    ArticleNum VARCHAR(7) NOT NULL UNIQUE,
    MinPartnerPrice DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (IDTypeProduct) REFERENCES TypeProducts(TDTypeProduct),
    FOREIGN KEY (IDTypeMaterial) REFERENCES TypeMaterial(IDTypeMaterial)
);

-- Таблица продукции в цехах 
CREATE TABLE ProductWorkshops (
    IDProductWorkshop INT IDENTITY(1,1) PRIMARY KEY,
    IDProducts INT NOT NULL,
    IDWorkshop INT NOT NULL,
    ManufacturingTime DECIMAL(5,2) NOT NULL, -- время в часах
    FOREIGN KEY (IDProducts) REFERENCES Products(IDProducts),
    FOREIGN KEY (IDWorkshop) REFERENCES Workshops(IDWorkshop)
);

-- Заполнение таблицы типов продукции
INSERT INTO TypeProducts (TypeName, TypeCoefficient) VALUES
('Гостиные', 3.5),
('Прихожие', 5.6),
('Мягкая мебель', 3.0),
('Кровати', 4.7),
('Шкафы', 1.5),
('Комоды', 2.3);

-- Заполнение таблицы типов материалов
INSERT INTO TypeMaterial (MaterialName, ProssentLosses) VALUES
('Мебельный щит из массива дерева', 0.80),
('Ламинированное ДСП', 0.70),
('Фанера', 0.55),
('МДФ', 0.30);

-- Заполнение таблицы цехов
INSERT INTO Workshops (WorkshopName, WorkshopType, PeopleCount) VALUES
('Проектный', 'Проектирование', 4),
('Расчетный', 'Проектирование', 5),
('Раскроя', 'Обработка', 5),
('Обработки', 'Обработка', 6),
('Сушильный', 'Сушка', 3),
('Покраски', 'Обработка', 5),
('Столярный', 'Обработка', 7),
('Изготовления изделий из искусственного камня и композитных материалов', 'Обработка', 3),
('Изготовления мягкой мебели', 'Обработка', 5),
('Монтажа стеклянных, зеркальных вставок и других изделий', 'Сборка', 2),
('Сборки', 'Сборка', 6),
('Упаковки', 'Сборка', 4);

-- Заполнение таблицы продукции
INSERT INTO Products (ArticleNum, IDTypeProduct, ProductName, MinPartnerPrice, IDTypeMaterial) VALUES
('1549922', 1, 'Комплект мебели для гостиной Ольха горная', 160507.00, 1),
('1018556', 1, 'Стенка для гостиной Вишня темная', 216907.00, 1),
('3028272', 2, 'Прихожая Венге Винтаж', 24970.00, 2),
('3029272', 2, 'Тумба с вешалкой Дуб натуральный', 18206.00, 2),
('3028248', 2, 'Прихожая-комплект Дуб темный', 177509.00, 1),
('7118827', 3, 'Диван-кровать угловой Книжка', 85900.00, 1),
('7137981', 3, 'Диван модульный Телескоп', 75900.00, 1),
('7029787', 3, 'Диван-кровать Соло', 120345.00, 1),
('7738953', 3, 'Детский диван Выкатной', 25990.00, 3),
('6026662', 4, 'Кровать с подъемным механизмом с матрасом 1600х2000 Венге', 69500.00, 1),
('6159043', 4, 'Кровать с матрасом 90х2000 Венге', 55600.00, 2),
('6588376', 4, 'Кровать универсальная Дуб натуральный', 37900.00, 2),
('6758375', 4, 'Кровать с ящиками Ясень белый', 46750.00, 3),
('2759324', 5, 'Шкаф-купе 3-х дверный Сосна белая', 131560.00, 2),
('2118827', 5, 'Стеллаж Бук натуральный', 38700.00, 1),
('2559838', 5, 'Шкаф 4 дверный с ящиками Ясень серый', 160151.00, 3),
('2259474', 5, 'Шкаф-пенал Береза белый', 40500.00, 3),
('4115947', 6, 'Комод 6 ящиков Вишня светлая', 61235.00, 1),
('4033136', 6, 'Комод 4 ящика Вишня светлая', 41200.00, 1),
('4028048', 6, 'Тумба под ТВ', 12350.00, 4);

-- Заполнение таблицы ProductWorkshops
INSERT INTO ProductWorkshops (IDProducts, IDWorkshop, ManufacturingTime) VALUES
(10, 8, 2.0),
(20, 8, 2.7),
(6, 9, 4.2),
(7, 9, 4.5),
(8, 9, 4.7),
(9, 9, 4.0),
(11, 9, 5.5),
(2, 10, 0.3),
(3, 10, 0.5),
(5, 10, 0.3),
(10, 10, 0.5),
(14, 10, 0.5),
(20, 10, 1.0),
(1, 4, 0.5),
(2, 4, 0.3),
(3, 4, 0.5),
(4, 4, 0.5),
(5, 4, 0.5),
(6, 4, 0.5),
(7, 4, 0.5),
(8, 4, 0.5),
(9, 4, 0.3),
(10, 4, 0.6),
(11, 4, 1.0),
(12, 4, 0.8),
(13, 4, 2.0),
(14, 4, 0.5),
(15, 4, 0.3),
(16, 4, 1.5),
(17, 4, 1.0),
(18, 4, 0.5),
(19, 4, 0.4),
(20, 4, 0.5),
(1, 6, 0.3),
(2, 6, 0.4),
(5, 6, 0.5),
(6, 6, 0.5),
(7, 6, 1.0),
(8, 6, 0.5),
(9, 6, 0.5),
(10, 6, 0.4),
(13, 6, 1.5),
(15, 6, 1.0),
(17, 6, 2.5),
(18, 6, 1.0),
(19, 6, 0.4),
(20, 6, 0.5),
(1, 1, 1.0),
(2, 1, 1.0),
(5, 1, 1.5),
(8, 1, 0.5),
(14, 1, 2.0),
(15, 1, 1.0),
(20, 1, 1.0),
(1, 3, 1.0),
(2, 3, 1.0),
(3, 3, 1.0),
(4, 3, 1.0),
(5, 3, 1.0),
(6, 3, 1.0),
(7, 3, 1.0),
(8, 3, 0.5),
(9, 3, 0.7),
(10, 3, 1.0),
(11, 3, 1.0),
(12, 3, 1.1),
(13, 3, 2.0),
(14, 3, 1.0),
(15, 3, 1.0),
(16, 3, 1.0),
(17, 3, 1.0),
(18, 3, 1.0),
(19, 3, 1.0),
(20, 3, 0.6),
(1, 2, 0.4),
(2, 2, 1.0),
(5, 2, 0.5),
(8, 2, 0.5),
(14, 2, 1.0),
(15, 2, 0.7),
(20, 2, 0.4),
(2, 11, 1.0),
(3, 11, 1.0),
(5, 11, 0.5),
(6, 11, 0.5),
(7, 11, 0.3),
(12, 11, 0.8),
(13, 11, 0.3),
(14, 11, 1.5),
(15, 11, 0.3),
(16, 11, 2.0),
(18, 11, 0.3),
(20, 11, 1.0),
(1, 7, 1.5),
(2, 7, 1.0),
(5, 7, 1.0),
(7, 7, 0.5),
(8, 7, 0.5),
(9, 7, 1.0),
(15, 7, 0.5),
(16, 7, 1.0),
(17, 7, 3.0),
(18, 7, 2.0),
(19, 7, 2.0),
(1, 5, 2.0),
(2, 5, 2.0),
(5, 5, 2.0),
(6, 5, 2.0),
(7, 5, 2.0),
(15, 5, 2.0),
(18, 5, 2.0),
(19, 5, 2.0),
(1, 12, 0.3),
(4, 12, 0.5),
(5, 12, 0.2),
(6, 12, 0.3),
(7, 12, 0.2),
(8, 12, 0.3),
(9, 12, 0.5),
(10, 12, 0.5),
(11, 12, 0.5),
(12, 12, 0.3),
(13, 12, 0.2),
(14, 12, 0.5),
(15, 12, 0.2),
(16, 12, 0.5),
(17, 12, 0.5),
(18, 12, 0.2),
(19, 12, 0.2),
(20, 12, 0.3);


GO

-- Создание представления для отображения продукции с временем изготовления
CREATE VIEW ProductsWithManufacturingTime AS
SELECT 
    p.IDProducts AS ProductId,
    p.ArticleNum AS Article,
    tp.TypeName AS ProductType,
    p.ProductName,
    p.MinPartnerPrice,
    tm.MaterialName AS MainMaterial,
    ISNULL(SUM(pw.ManufacturingTime), 0) AS TotalManufacturingTime
FROM Products p
LEFT JOIN TypeProducts tp ON p.IDTypeProduct = tp.TDTypeProduct
LEFT JOIN TypeMaterial tm ON p.IDTypeMaterial = tm.IDTypeMaterial
LEFT JOIN ProductWorkshops pw ON p.IDProducts = pw.IDProducts
GROUP BY 
    p.IDProducts, 
    p.ArticleNum, 
    tp.TypeName, 
    p.ProductName, 
    p.MinPartnerPrice, 
    tm.MaterialName;
GO

-- Создание хранимой процедуры для расчета количества сырья
CREATE PROCEDURE CalculateRawMaterialQuantity
    @ProductTypeId INT,
    @MaterialTypeId INT,
    @ProductQuantity INT,
    @Parameter1 DECIMAL(10,2),
    @Parameter2 DECIMAL(10,2),
    @Result INT OUTPUT
AS
BEGIN
    DECLARE @TypeCoefficient DECIMAL(5,2);
    DECLARE @ProssentLosses DECIMAL(5,2);
    DECLARE @RawMaterialPerUnit DECIMAL(10,2);
    DECLARE @TotalRawMaterial DECIMAL(10,2);

    -- Получение коэффициента типа продукции
    SELECT @TypeCoefficient = TypeCoefficient
    FROM TypeProducts
    WHERE TDTypeProduct = @ProductTypeId;

    -- Получение процента потерь по типу материала
    SELECT @ProssentLosses = ProssentLosses
    FROM TypeMaterial
    WHERE IDTypeMaterial = @MaterialTypeId;

    -- Проверка валидности данных
    IF @TypeCoefficient IS NULL OR @ProssentLosses IS NULL OR
       @ProductQuantity <= 0 OR @Parameter1 <= 0 OR @Parameter2 <= 0
    BEGIN
        SET @Result = -1;
        RETURN;
    END

    -- Расчет количества сырья на единицу продукции
    SET @RawMaterialPerUnit = @Parameter1 * @Parameter2 * @TypeCoefficient;

    -- Расчет общего количества с учетом потерь
    SET @TotalRawMaterial = @RawMaterialPerUnit * @ProductQuantity * (1 + @ProssentLosses / 100);

    -- Округление вверх
    SET @Result = CEILING(@TotalRawMaterial);
END;
GO

PRINT 'База данных FurnitureCompanyDB успешно создана и заполнена данными!'; 