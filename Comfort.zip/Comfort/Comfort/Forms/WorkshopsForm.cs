using System;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Comfort
{
    // Форма для отображения информации о цехах, связанных с продуктом
    public partial class WorkshopsForm : Form
    {
        private int productId;

        // Конструктор: сохраняет идентификатор продукта и загружает список цехов
        public WorkshopsForm(int productId)
        {
            InitializeComponent();
            this.productId = productId;
            LoadWorkshops();
        }

        // Загружает данные о цехах из базы и отображает их в таблице
        private void LoadWorkshops()
        {
            try
            {
                string connStr = ConfigurationManager.ConnectionStrings["ComfortDB"].ConnectionString;
                using (var conn = new SqlConnection(connStr))
                {
                    conn.Open();
                    var dt = new DataTable();
                    string query = @"
                        SELECT w.WorkshopName AS [Название цеха],
                               w.StaffCount   AS [Количество работников],
                               pw.ManufacturingTime AS [Время изготовления]
                        FROM ProductWorkshops pw
                        INNER JOIN Workshops w ON pw.WorkshopID = w.WorkshopID
                        WHERE pw.ProductID = @pid";
                    using (var da = new SqlDataAdapter(query, conn))
                    {
                        da.SelectCommand.Parameters.AddWithValue("@pid", productId);
                        da.Fill(dt);
                    }
                    dgvWorkshops.DataSource = dt;
                    dgvWorkshops.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Не удалось загрузить данные цехов: {ex.Message}", "Ошибка подключения", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Обрабатывает нажатие 'Закрыть': закрывает форму
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
} 
