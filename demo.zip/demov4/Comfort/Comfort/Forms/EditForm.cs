using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace Comfort
{
    // Форма для редактирования существующего продукта
    public partial class EditForm : Form
    {
        private int productId;

        // Конструктор: инициализирует компоненты, настраивает форму и загружает данные продукта
        public EditForm(int productId)
        {
            InitializeComponent();
            LoadComboBoxes();
            this.productId = productId;
            this.Text = "Редактировать продукт";
            lblFormTitle.Text = "Редактировать продукт";
            LoadProduct();
        }

        // Загружает типы продуктов и материалы в комбобоксы из базы данных
        private void LoadComboBoxes()
        {
            // Если нет соединения с БД, пропускаем загрузку
            if (!Program.DbAvailable)
                return;
            string connStr = ConfigurationManager.ConnectionStrings["ComfortDB"].ConnectionString;
            using (var conn = new SqlConnection(connStr))
            {
                conn.Open();
                var dtTypes = new DataTable();
                using (var da = new SqlDataAdapter("SELECT ProductTypeID, ProductTypeName FROM ProductTypes", conn))
                    da.Fill(dtTypes);
                cmbProductType.DataSource = dtTypes;
                cmbProductType.ValueMember = "ProductTypeID";
                cmbProductType.DisplayMember = "ProductTypeName";

                var dtMaterials = new DataTable();
                using (var da = new SqlDataAdapter("SELECT MaterialID, MaterialName FROM Materials", conn))
                    da.Fill(dtMaterials);
                cmbMaterial.DataSource = dtMaterials;
                cmbMaterial.ValueMember = "MaterialID";
                cmbMaterial.DisplayMember = "MaterialName";
            }
        }

        // Загружает данные выбранного продукта из базы для редактирования
        private void LoadProduct()
        {
            // Если нет соединения с БД, пропускаем загрузку данных продукта
            if (!Program.DbAvailable)
                return;
            string connStr = ConfigurationManager.ConnectionStrings["ComfortDB"].ConnectionString;
            using (var conn = new SqlConnection(connStr))
            using (var cmd = new SqlCommand(
                "SELECT Article, ProductTypeID, ProductName, MinPartnerCost, MainMaterialID FROM Products WHERE ProductID = @id", conn))
            {
                cmd.Parameters.AddWithValue("@id", productId);
                conn.Open();
                using (var reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        txtArticle.Text = reader.GetString(0);
                        cmbProductType.SelectedValue = reader.GetInt32(1);
                        txtProductName.Text = reader.GetString(2);
                        nudMinCost.Value = reader.GetDecimal(3);
                        cmbMaterial.SelectedValue = reader.GetInt32(4);
                    }
                }
            }
        }

        // Обрабатывает нажатие 'Сохранить': проверяет ввод и обновляет данные в базе
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtArticle.Text) || string.IsNullOrWhiteSpace(txtProductName.Text))
            {
                MessageBox.Show("Поля 'Артикул' и 'Наименование' обязательны.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (nudMinCost.Value < 0)
            {
                MessageBox.Show("Стоимость не может быть отрицательной.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            try
            {
                string connStr = ConfigurationManager.ConnectionStrings["ComfortDB"].ConnectionString;
                using (var conn = new SqlConnection(connStr))
                using (var cmd = new SqlCommand(
                    "UPDATE Products SET Article=@article, ProductTypeID=@typeId, ProductName=@name, MinPartnerCost=@cost, MainMaterialID=@materialId WHERE ProductID=@id", conn))
                {
                    cmd.Parameters.AddWithValue("@article", txtArticle.Text);
                    cmd.Parameters.AddWithValue("@typeId", cmbProductType.SelectedValue);
                    cmd.Parameters.AddWithValue("@name", txtProductName.Text);
                    cmd.Parameters.AddWithValue("@cost", nudMinCost.Value);
                    cmd.Parameters.AddWithValue("@materialId", cmbMaterial.SelectedValue);
                    cmd.Parameters.AddWithValue("@id", productId);
                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
                MessageBox.Show("Продукт успешно обновлён.", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при обновлении данных: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Обрабатывает нажатие 'Назад': закрывает форму без изменений
        private void btnBack_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
} 
