using System;
using System.Configuration;
using System.Data.SqlClient;

namespace Comfort
{
    // Утилита для расчёта необходимого количества сырья
    public static class RawMaterialsCalculator
    {
        // Рассчитывает количество сырья для продукта с учётом размеров и потерь
        public static int CalculateRawMaterials(int productTypeId, int materialTypeId, int quantity, double length, double width)
        {
            if (productTypeId <= 0 || materialTypeId <= 0 || quantity < 0 || length <= 0 || width <= 0)
                return -1;

            double coefficient;
            double lossPercent;

            string connStr = ConfigurationManager.ConnectionStrings["ComfortDB"].ConnectionString;
            using (var conn = new SqlConnection(connStr))
            {
                conn.Open();
                
                using (var cmd = new SqlCommand("SELECT Coefficient FROM ProductTypes WHERE ProductTypeID = @ptId", conn))
                {
                    cmd.Parameters.AddWithValue("@ptId", productTypeId);
                    var res = cmd.ExecuteScalar();
                    if (res == null || !double.TryParse(res.ToString(), out coefficient))
                        return -1;
                }
                
                using (var cmd = new SqlCommand("SELECT LossPercentage FROM Materials WHERE MaterialID = @mId", conn))
                {
                    cmd.Parameters.AddWithValue("@mId", materialTypeId);
                    var res = cmd.ExecuteScalar();
                    if (res == null || !double.TryParse(res.ToString(), out lossPercent))
                        return -1;
                }
            }

            
            double amountPerUnit = length * width * coefficient;
            double totalRaw = amountPerUnit * quantity;
            double totalWithLoss = totalRaw * (1 + lossPercent);
            return (int)Math.Ceiling(totalWithLoss);
        }
    }
} 
