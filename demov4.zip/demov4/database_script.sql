-- Создание базы данных для системы управления продукцией мебельной компании "Комфорт"
-- Скрипт создан на основе данных из Excel файлов

USE master;
GO

-- Создание базы данных
IF EXISTS (SELECT name FROM sys.databases WHERE name = 'FurnitureCompany')
    DROP DATABASE FurnitureCompany;
GO

CREATE DATABASE FurnitureCompany;
GO

USE FurnitureCompany;
GO

-- Таблица типов продукции
CREATE TABLE ProductTypes (
    ProductTypeId INT IDENTITY(1,1) PRIMARY KEY,
    TypeName NVARCHAR(100) NOT NULL,
    TypeCoefficient DECIMAL(5,2) NOT NULL
);

-- Таблица типов материалов
CREATE TABLE MaterialTypes (
    MaterialTypeId INT IDENTITY(1,1) PRIMARY KEY,
    MaterialName NVARCHAR(100) NOT NULL,
    WastagePercentage DECIMAL(5,2) NOT NULL
);

-- Таблица цехов
CREATE TABLE Workshops (
    WorkshopId INT IDENTITY(1,1) PRIMARY KEY,
    WorkshopName NVARCHAR(100) NOT NULL,
    WorkshopType NVARCHAR(50) NOT NULL,
    PeopleCount INT NOT NULL
);

-- Таблица продукции
CREATE TABLE Products (
    ProductId INT IDENTITY(1,1) PRIMARY KEY,
    Article NVARCHAR(50) NOT NULL UNIQUE,
    ProductTypeId INT NOT NULL,
    ProductName NVARCHAR(200) NOT NULL,
    MinCostForPartner DECIMAL(10,2) NOT NULL,
    MainMaterial NVARCHAR(100) NOT NULL,
    FOREIGN KEY (ProductTypeId) REFERENCES ProductTypes(ProductTypeId)
);

-- Таблица связи продукции с цехами (время изготовления в каждом цехе)
CREATE TABLE ProductWorkshops (
    ProductWorkshopId INT IDENTITY(1,1) PRIMARY KEY,
    ProductId INT NOT NULL,
    WorkshopId INT NOT NULL,
    ManufacturingTime DECIMAL(5,2) NOT NULL, -- время в часах
    FOREIGN KEY (ProductId) REFERENCES Products(ProductId),
    FOREIGN KEY (WorkshopId) REFERENCES Workshops(WorkshopId)
);

-- Заполнение таблицы типов продукции
INSERT INTO ProductTypes (TypeName, TypeCoefficient) VALUES
('Гостиные', 3.5),
('Прихожие', 5.6),
('Мягкая мебель', 3.0),
('Кровати', 4.7),
('Шкафы', 1.5),
('Комоды', 2.3);

-- Заполнение таблицы типов материалов
INSERT INTO MaterialTypes (MaterialName, WastagePercentage) VALUES
('Мебельный щит из массива дерева', 0.80),
('Ламинированное ДСП', 0.70),
('Фанера', 0.55),
('МДФ', 0.30);

-- Заполнение таблицы цехов
INSERT INTO Workshops (WorkshopName, WorkshopType, PeopleCount) VALUES
('Проектный', 'Проектирование', 4),
('Расчетный', 'Проектирование', 5),
('Раскроя', 'Обработка', 5),
('Обработки', 'Обработка', 6),
('Сушильный', 'Сушка', 3),
('Покраски', 'Обработка', 5),
('Столярный', 'Обработка', 7),
('Изготовления изделий из искусственного камня и композитных материалов', 'Обработка', 3),
('Изготовления мягкой мебели', 'Обработка', 5),
('Монтажа стеклянных, зеркальных вставок и других изделий', 'Сборка', 2),
('Сборки', 'Сборка', 6),
('Упаковки', 'Сборка', 4);

-- Заполнение таблицы продукции
INSERT INTO Products (Article, ProductTypeId, ProductName, MinCostForPartner, MainMaterial) VALUES
('1549922', 1, 'Комплект мебели для гостиной Ольха горная', 160507.00, 'Мебельный щит из массива дерева'),
('1018556', 1, 'Стенка для гостиной Вишня темная', 216907.00, 'Мебельный щит из массива дерева'),
('3028272', 2, 'Прихожая Венге Винтаж', 24970.00, 'Ламинированное ДСП'),
('3029272', 2, 'Тумба с вешалкой Дуб натуральный', 18206.00, 'Ламинированное ДСП'),
('3028248', 2, 'Прихожая-комплект Дуб темный', 177509.00, 'Мебельный щит из массива дерева'),
('7118827', 3, 'Диван-кровать угловой Книжка', 85900.00, 'Мебельный щит из массива дерева'),
('7137981', 3, 'Диван модульный Телескоп', 75900.00, 'Мебельный щит из массива дерева'),
('7029787', 3, 'Диван-кровать Соло', 120345.00, 'Мебельный щит из массива дерева'),
('7738953', 3, 'Детский диван Выкатной', 25990.00, 'Фанера'),
('6026662', 4, 'Кровать с подъемным механизмом с матрасом 1600х2000 Венге', 69500.00, 'Мебельный щит из массива дерева'),
('6159043', 4, 'Кровать с матрасом 90х2000 Венге', 55600.00, 'Ламинированное ДСП'),
('6588376', 4, 'Кровать универсальная Дуб натуральный', 37900.00, 'Ламинированное ДСП'),
('6758375', 4, 'Кровать с ящиками Ясень белый', 46750.00, 'Фанера'),
('2759324', 5, 'Шкаф-купе 3-х дверный Сосна белая', 131560.00, 'Ламинированное ДСП'),
('2118827', 5, 'Стеллаж Бук натуральный', 38700.00, 'Мебельный щит из массива дерева'),
('2559838', 5, 'Шкаф 4 дверный с ящиками Ясень серый', 160151.00, 'Фанера'),
('2259474', 5, 'Шкаф-пенал Береза белый', 40500.00, 'Фанера'),
('4115947', 6, 'Комод 6 ящиков Вишня светлая', 61235.00, 'Мебельный щит из массива дерева'),
('4033136', 6, 'Комод 4 ящика Вишня светлая', 41200.00, 'Мебельный щит из массива дерева'),
('4028048', 6, 'Тумба под ТВ', 12350.00, 'МДФ');

-- Заполнение времени изготовления продукции в цехах
INSERT INTO ProductWorkshops (ProductId, WorkshopId, ManufacturingTime) VALUES
-- Кровать с подъемным механизмом с матрасом 1600х2000 Венге
(10, 7, 2.0), -- Изготовления изделий из искусственного камня и композитных материалов
(10, 8, 2.7), -- Изготовления мягкой мебели

-- Тумба под ТВ
(20, 7, 4.2), -- Изготовления мягкой мебели

-- Диван модульный Телескоп
(7, 5, 4.5), -- Изготовления мягкой мебели

-- Диван-кровать Соло
(8, 5, 4.7), -- Изготовления мягкой мебели

-- Детский диван Выкатной
(9, 5, 4.0), -- Изготовления мягкой мебели

-- Кровать с матрасом 90х2000 Венге
(11, 5, 5.5), -- Изготовления мягкой мебели

-- Стенка для гостиной Вишня темная
(2, 10, 0.3), -- Монтажа стеклянных, зеркальных вставок и других изделий

-- Прихожая Венге Винтаж
(3, 10, 0.5), -- Монтажа стеклянных, зеркальных вставок и других изделий

-- Прихожая-комплект Дуб темный
(5, 10, 0.3), -- Монтажа стеклянных, зеркальных вставок и других изделий

-- Кровать с подъемным механизмом с матрасом 1600х2000 Венге
(10, 10, 0.5), -- Монтажа стеклянных, зеркальных вставок и других изделий

-- Шкаф-купе 3-х дверный Сосна белая
(14, 10, 0.5), -- Монтажа стеклянных, зеркальных вставок и других изделий

-- Тумба под ТВ
(20, 10, 1.0), -- Монтажа стеклянных, зеркальных вставок и других изделий

-- Комплект мебели для гостиной Ольха горная
(1, 4, 0.5), -- Обработки

-- Стенка для гостиной Вишня темная
(2, 4, 0.3), -- Обработки

-- Прихожая Венге Винтаж
(3, 4, 0.5), -- Обработки

-- Тумба с вешалкой Дуб натуральный
(4, 4, 0.5), -- Обработки

-- Прихожая-комплект Дуб темный
(5, 4, 0.5), -- Обработки

-- Диван-кровать угловой Книжка
(6, 4, 0.5), -- Обработки

-- Диван модульный Телескоп
(7, 4, 0.5), -- Обработки

-- Диван-кровать Соло
(8, 4, 0.5), -- Обработки

-- Детский диван Выкатной
(9, 4, 0.3), -- Обработки

-- Кровать с подъемным механизмом с матрасом 1600х2000 Венге
(10, 4, 0.6), -- Обработки

-- Кровать с матрасом 90х2000 Венге
(11, 4, 1.0), -- Обработки

-- Кровать универсальная Дуб натуральный
(12, 4, 0.8), -- Обработки

-- Кровать с ящиками Ясень белый
(13, 4, 2.0), -- Обработки

-- Шкаф-купе 3-х дверный Сосна белая
(14, 4, 0.5), -- Обработки

-- Стеллаж Бук натуральный
(15, 4, 0.3), -- Обработки

-- Шкаф 4 дверный с ящиками Ясень серый
(16, 4, 1.5), -- Обработки

-- Шкаф-пенал Береза белый
(17, 4, 1.0), -- Обработки

-- Комод 6 ящиков Вишня светлая
(18, 4, 0.5), -- Обработки

-- Комод 4 ящика Вишня светлая
(19, 4, 0.4), -- Обработки

-- Тумба под ТВ
(20, 4, 0.5), -- Обработки

-- Комплект мебели для гостиной Ольха горная
(1, 9, 0.3), -- Покраски

-- Стенка для гостиной Вишня темная
(2, 9, 0.4), -- Покраски

-- Прихожая-комплект Дуб темный
(5, 9, 0.5), -- Покраски

-- Диван-кровать угловой Книжка
(6, 9, 0.5); -- Покраски

GO

-- Создание представления для отображения продукции с временем изготовления
CREATE VIEW ProductsWithManufacturingTime AS
SELECT 
    p.ProductId,
    p.Article,
    pt.TypeName AS ProductType,
    p.ProductName,
    p.MinCostForPartner,
    p.MainMaterial,
    ISNULL(SUM(pw.ManufacturingTime), 0) AS TotalManufacturingTime
FROM Products p
LEFT JOIN ProductTypes pt ON p.ProductTypeId = pt.ProductTypeId
LEFT JOIN ProductWorkshops pw ON p.ProductId = pw.ProductId
GROUP BY p.ProductId, p.Article, pt.TypeName, p.ProductName, p.MinCostForPartner, p.MainMaterial;

GO

-- Создание хранимой процедуры для расчета количества сырья
CREATE PROCEDURE CalculateRawMaterialQuantity
    @ProductTypeId INT,
    @MaterialTypeId INT,
    @ProductQuantity INT,
    @Parameter1 DECIMAL(10,2),
    @Parameter2 DECIMAL(10,2),
    @Result INT OUTPUT
AS
BEGIN
    DECLARE @TypeCoefficient DECIMAL(5,2);
    DECLARE @WastagePercentage DECIMAL(5,2);
    DECLARE @RawMaterialPerUnit DECIMAL(10,2);
    DECLARE @TotalRawMaterial DECIMAL(10,2);
    
    -- Проверка существования типа продукции
    SELECT @TypeCoefficient = TypeCoefficient 
    FROM ProductTypes 
    WHERE ProductTypeId = @ProductTypeId;
    
    -- Проверка существования типа материала
    SELECT @WastagePercentage = WastagePercentage 
    FROM MaterialTypes 
    WHERE MaterialTypeId = @MaterialTypeId;
    
    -- Если типы не найдены или параметры некорректны
    IF @TypeCoefficient IS NULL OR @WastagePercentage IS NULL OR 
       @ProductQuantity <= 0 OR @Parameter1 <= 0 OR @Parameter2 <= 0
    BEGIN
        SET @Result = -1;
        RETURN;
    END
    
    -- Расчет количества сырья на единицу продукции
    SET @RawMaterialPerUnit = @Parameter1 * @Parameter2 * @TypeCoefficient;
    
    -- Расчет общего количества с учетом потерь
    SET @TotalRawMaterial = @RawMaterialPerUnit * @ProductQuantity * (1 + @WastagePercentage / 100);
    
    -- Округление до целого числа в большую сторону
    SET @Result = CEILING(@TotalRawMaterial);
END;

GO

PRINT 'База данных FurnitureCompany успешно создана и заполнена данными!'; 