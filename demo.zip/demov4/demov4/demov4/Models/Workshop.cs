namespace demov4.Models
{
    /// <summary>
    /// Модель цеха производства
    /// </summary>
    public class Workshop
    {
        public int WorkshopId { get; set; }
        public string WorkshopName { get; set; }
        public string WorkshopType { get; set; }
        public int PeopleCount { get; set; }
        public decimal ManufacturingTime { get; set; }

        /// <summary>
        /// Форматированное время для отображения
        /// </summary>
        public string FormattedTime
        {
            get
            {
                return $"{ManufacturingTime:F1} ч";
            }
        }
    }
} 