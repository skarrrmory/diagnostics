using System;

namespace demov4.Models
{
    /// <summary>
    /// Модель продукции компании
    /// </summary>
    public class Product
    {
        public int ProductId { get; set; }
        public string Article { get; set; }
        public int ProductTypeId { get; set; }
        public string ProductType { get; set; }
        public string ProductName { get; set; }
        public decimal MinCostForPartner { get; set; }
        public string MainMaterial { get; set; }
        public decimal TotalManufacturingTime { get; set; }

        /// <summary>
        /// Форматированное время изготовления для отображения
        /// </summary>
        public string FormattedManufacturingTime
        {
            get
            {
                return $"{Math.Ceiling(TotalManufacturingTime)} ч";
            }
        }

        /// <summary>
        /// Форматированная стоимость для отображения
        /// </summary>
        public string FormattedCost
        {
            get
            {
                return $"{MinCostForPartner:N2} руб.";
            }
        }
    }
} 