using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;

namespace Comfort
{
    // Главное окно приложения: отображает продукты и предоставляет функции добавления, редактирования, удаления, просмотра цехов и расчёта сырья
    public partial class Form1 : Form
    {
        private int? selectedProductId;
        private Panel selectedCard;

        // Конструктор: настраивает форму, загружает логотип и данные продуктов
        public Form1()
        {
            InitializeComponent();
            
            this.flowLayoutPanelProducts.SizeChanged += (s, e) =>
            {
                foreach (Panel card in flowLayoutPanelProducts.Controls.OfType<Panel>())
                    card.Width = flowLayoutPanelProducts.ClientSize.Width - 10;
            };
            LoadLogo();
            
            if (pictureBoxLogo.Image is System.Drawing.Bitmap bmp)
                this.Icon = System.Drawing.Icon.FromHandle(bmp.GetHicon());
            LoadData();
        }

        // Загружает логотип приложения из файла, если он существует в каталоге приложения
        private void LoadLogo()
        {
            string logoPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Комфорт.png");
            if (File.Exists(logoPath))
                pictureBoxLogo.Image = Image.FromFile(logoPath);
        }

        // Загружает список продуктов из базы данных и отображает их в виде карточек
        private void LoadData()
        {
            // Если нет соединения с БД, очищаем карточки и выходим
            if (!Program.DbAvailable)
            {
                flowLayoutPanelProducts.Controls.Clear();
                return;
            }
            
            selectedProductId = null;
            if (selectedCard != null)
                selectedCard.BackColor = Color.White;
            selectedCard = null;
            btnEdit.Enabled = false;
            btnDelete.Enabled = false;
            string connStr = ConfigurationManager.ConnectionStrings["ComfortDB"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                string query = @"
                    SELECT p.ProductID, p.Article, p.ProductName,
                           pt.ProductTypeName,
                           ISNULL(SUM(pw.ManufacturingTime), 0) AS TotalTime,
                           p.MinPartnerCost, m.MaterialName
                    FROM Products p
                    LEFT JOIN ProductTypes pt ON p.ProductTypeID = pt.ProductTypeID
                    LEFT JOIN ProductWorkshops pw ON p.ProductID = pw.ProductID
                    LEFT JOIN Materials m ON p.MainMaterialID = m.MaterialID
                    GROUP BY p.ProductID, p.Article, p.ProductName, pt.ProductTypeName, p.MinPartnerCost, m.MaterialName";
                DataTable dt = new DataTable();
                using (SqlDataAdapter da = new SqlDataAdapter(query, conn))
                    da.Fill(dt);
                dt.Columns.Add("ВремяИзготовления", typeof(int));
                foreach (DataRow row in dt.Rows)
                {
                    decimal total = Convert.ToDecimal(row["TotalTime"]);
                    int time = (int)Math.Round(total, MidpointRounding.AwayFromZero);
                    row["ВремяИзготовления"] = time;
                }
                dt.Columns.Remove("TotalTime");
                
                flowLayoutPanelProducts.Controls.Clear();
                
                foreach (DataRow row in dt.Rows)
                {
                    string typeName = row["ProductTypeName"].ToString();
                    string prodName = row["ProductName"].ToString();
                    string article = row["Article"].ToString();
                    string cost = Convert.ToDecimal(row["MinPartnerCost"]).ToString("N2");
                    string material = row["MaterialName"].ToString();
                    string prodTime = row["ВремяИзготовления"].ToString();

                    Panel card = new Panel
                    {
                        Width = flowLayoutPanelProducts.ClientSize.Width - 20,
                        Height = 80,
                        BackColor = Color.White,
                        BorderStyle = BorderStyle.FixedSingle,
                        Margin = new Padding(5)
                    };
                    
                    Label lblHeader = new Label
                    {
                        Text = $"{typeName} | {prodName}",
                        Font = new Font("Candara", 9F, FontStyle.Bold, GraphicsUnit.Point, ((byte)(204))),
                        AutoSize = false,
                        Location = new Point(5, 5),
                        Size = new Size(card.Width - 100, 20)
                    };
                    card.Controls.Add(lblHeader);
                    
                    Label lblArticle = new Label
                    {
                        Text = $"Артикул: {article}",
                        Font = new Font("Candara", 8.25F),
                        AutoSize = true,
                        Location = new Point(5, 30)
                    };
                    card.Controls.Add(lblArticle);
                    
                    Label lblCost = new Label
                    {
                        Text = $"Минимальная стоимость для партнера: {cost}",
                        Font = new Font("Candara", 8.25F),
                        AutoSize = true,
                        Location = new Point(5, 45)
                    };
                    card.Controls.Add(lblCost);
                    
                    Label lblMaterial = new Label
                    {
                        Text = $"Основной материал: {material}",
                        Font = new Font("Candara", 8.25F),
                        AutoSize = true,
                        Location = new Point(5, 60)
                    };
                    card.Controls.Add(lblMaterial);
                    
                    Label lblTime = new Label
                    {
                        Text = $"{prodTime} ч",
                        Font = new Font("Candara", 12F, FontStyle.Bold),
                        AutoSize = true,
                        TextAlign = ContentAlignment.MiddleRight
                    };
                    card.Controls.Add(lblTime);
                    
                    lblTime.Anchor = AnchorStyles.Top | AnchorStyles.Right;
                    lblTime.Location = new Point(card.ClientSize.Width - lblTime.PreferredWidth - 10, lblHeader.Location.Y);
                    
                    flowLayoutPanelProducts.Controls.Add(card);
                    
                    card.Tag = Convert.ToInt32(row["ProductID"]);
                    Action<Control> attachHandler = null;
                    attachHandler = c =>
                    {
                        c.Click += (s, eArgs) => SelectCard(card);
                        c.DoubleClick += (s, eArgs) => OpenWorkshopsForCard(card);
                        foreach (Control child in c.Controls)
                            attachHandler(child);
                    };
                    attachHandler(card);
                }
            }
        }

        // Обрабатывает нажатие 'Добавить': открывает форму добавления нового продукта и обновляет список
        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                using (var form = new AddForm())
                {
                    if (form.ShowDialog() == DialogResult.OK)
                        LoadData();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при открытии формы добавления: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Обрабатывает выбор карточки продукта: подсвечивает её и сохраняет идентификатор выбранного продукта
        private void SelectCard(Panel card)
        {
            
            if (selectedCard != null)
                selectedCard.BackColor = Color.White;
            
            selectedCard = card;
            selectedProductId = (int)card.Tag;
            selectedCard.BackColor = ColorTranslator.FromHtml("#D2DFFF");
            btnEdit.Enabled = true;
            btnDelete.Enabled = true;
        }

        // Обрабатывает редактирование продукта: открывает форму редактирования для выбранного продукта
        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (!selectedProductId.HasValue)
                return;
            try
            {
                using (var form = new EditForm(selectedProductId.Value))
                {
                    if (form.ShowDialog() == DialogResult.OK)
                        LoadData();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при открытии формы редактирования: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Обрабатывает удаление продукта: подтверждает действие и удаляет данные из базы
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (!selectedProductId.HasValue)
                return;
            var result = MessageBox.Show(
                "Вы уверены, что хотите удалить выбранный продукт? Это действие необратимо.",
                "Подтвердите удаление",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);
            if (result != DialogResult.Yes)
                return;
            try
            {
                string connStr = ConfigurationManager.ConnectionStrings["ComfortDB"].ConnectionString;
                using (SqlConnection conn = new SqlConnection(connStr))
                {
                    conn.Open();
                    using (SqlCommand cmd = conn.CreateCommand())
                    {
                        
                        cmd.CommandText = "DELETE FROM ProductWorkshops WHERE ProductID = @id";
                        cmd.Parameters.AddWithValue("@id", selectedProductId.Value);
                        cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                        
                        cmd.CommandText = "DELETE FROM Products WHERE ProductID = @id";
                        cmd.Parameters.AddWithValue("@id", selectedProductId.Value);
                        int rows = cmd.ExecuteNonQuery();
                        if (rows > 0)
                            MessageBox.Show("Продукт успешно удалён.", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        else
                            MessageBox.Show("Продукт не найден или уже удалён.", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при удалении продукта: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
            LoadData();
        }

        // Открывает форму цехов для выбранного продукта при двойном клике на карточке
        private void OpenWorkshopsForCard(Panel card)
        {
            int productId = (int)card.Tag;
            using (var form = new WorkshopsForm(productId))
            {
                form.ShowDialog();
            }
        }

        // Открывает форму расчёта сырья
        private void btnRawMaterials_Click(object sender, EventArgs e)
        {
            using (var form = new RawMaterialsForm())
            {
                form.ShowDialog();
            }
        }
    }
}

