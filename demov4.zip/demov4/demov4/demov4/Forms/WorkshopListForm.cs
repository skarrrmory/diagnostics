using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using demov4.Data;
using demov4.Models;

namespace demov4.Forms
{
    /// <summary>
    /// Форма для отображения списка цехов для производства продукции
    /// </summary>
    public partial class WorkshopListForm : Form
    {
        private DatabaseHelper databaseHelper;
        private Product selectedProduct;
        private List<Workshop> workshops;
        private DataGridView dataGridViewWorkshops;
        private Button buttonBack;

        public WorkshopListForm(Product product)
        {
            InitializeComponent();
            databaseHelper = new DatabaseHelper();
            selectedProduct = product;
            InitializeCustomComponents();
            LoadWorkshops();
        }

        /// <summary>
        /// Инициализация пользовательских компонентов
        /// </summary>
        private void InitializeCustomComponents()
        {
            // Настройка формы
            this.Text = $"Цехи для производства - {selectedProduct.ProductName}";
            this.Size = new Size(800, 500);
            this.StartPosition = FormStartPosition.CenterParent;
            this.BackColor = Color.White;
            this.Font = new Font("Candara", 10F);

            // Заголовок с информацией о продукте
            var labelProductInfo = new Label
            {
                Text = $"Продукт: {selectedProduct.ProductName} (Артикул: {selectedProduct.Article})",
                Font = new Font("Candara", 12F, FontStyle.Bold),
                Location = new Point(20, 20),
                Size = new Size(750, 25),
                ForeColor = ColorTranslator.FromHtml("#355CBD")
            };

            var labelTitle = new Label
            {
                Text = "Список цехов для производства:",
                Font = new Font("Candara", 11F, FontStyle.Bold),
                Location = new Point(20, 55),
                Size = new Size(300, 25),
                ForeColor = Color.Black
            };

            // Отображение цехов
            dataGridViewWorkshops = new DataGridView
            {
                Location = new Point(20, 90),
                Size = new Size(740, 320),
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                Font = new Font("Candara", 9F)
            };

            // Настройка стиля
            dataGridViewWorkshops.EnableHeadersVisualStyles = false;
            dataGridViewWorkshops.ColumnHeadersDefaultCellStyle.BackColor = ColorTranslator.FromHtml("#D2DFFF");
            dataGridViewWorkshops.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black;
            dataGridViewWorkshops.ColumnHeadersDefaultCellStyle.Font = new Font("Candara", 10F, FontStyle.Bold);
            dataGridViewWorkshops.ColumnHeadersHeight = 35;

            dataGridViewWorkshops.DefaultCellStyle.SelectionBackColor = ColorTranslator.FromHtml("#355CBD");
            dataGridViewWorkshops.DefaultCellStyle.SelectionForeColor = Color.White;
            dataGridViewWorkshops.AlternatingRowsDefaultCellStyle.BackColor = ColorTranslator.FromHtml("#F8F9FF");

            // Кнопка "Назад"
            buttonBack = new Button
            {
                Text = "Назад",
                Font = new Font("Candara", 10F),
                Size = new Size(100, 35),
                Location = new Point(660, 420),
                BackColor = ColorTranslator.FromHtml("#D2DFFF"),
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand
            };
            buttonBack.FlatAppearance.BorderSize = 0;
            buttonBack.Click += ButtonBack_Click;

            // Добавление компонентов на форму
            this.Controls.Add(labelProductInfo);
            this.Controls.Add(labelTitle);
            this.Controls.Add(dataGridViewWorkshops);
            this.Controls.Add(buttonBack);
        }

        /// <summary>
        /// Загрузка списка цехов для выбранного продукта
        /// </summary>
        private void LoadWorkshops()
        {
            try
            {
                workshops = databaseHelper.GetWorkshopsForProduct(selectedProduct.ProductId);

                // Настройка колонок DataGridView
                dataGridViewWorkshops.DataSource = null;
                dataGridViewWorkshops.Columns.Clear();

                dataGridViewWorkshops.Columns.Add(new DataGridViewTextBoxColumn
                {
                    Name = "WorkshopName",
                    HeaderText = "Название цеха",
                    DataPropertyName = "WorkshopName",
                    Width = 300
                });

                dataGridViewWorkshops.Columns.Add(new DataGridViewTextBoxColumn
                {
                    Name = "WorkshopType",
                    HeaderText = "Тип цеха",
                    DataPropertyName = "WorkshopType",
                    Width = 150
                });

                dataGridViewWorkshops.Columns.Add(new DataGridViewTextBoxColumn
                {
                    Name = "PeopleCount",
                    HeaderText = "Количество человек",
                    DataPropertyName = "PeopleCount",
                    Width = 150
                });

                dataGridViewWorkshops.Columns.Add(new DataGridViewTextBoxColumn
                {
                    Name = "FormattedTime",
                    HeaderText = "Время изготовления",
                    DataPropertyName = "FormattedTime",
                    Width = 140
                });

                dataGridViewWorkshops.DataSource = workshops;

                // Обновление заголовка с количеством цехов
                if (workshops.Count == 0)
                {
                    var labelNoData = new Label
                    {
                        Text = "Для данного продукта не найдено цехов производства.",
                        Font = new Font("Candara", 10F, FontStyle.Italic),
                        Location = new Point(20, 200),
                        Size = new Size(400, 25),
                        ForeColor = Color.Gray
                    };
                    this.Controls.Add(labelNoData);
                }
                else
                {
                    // Расчет общего времени изготовления
                    decimal totalTime = workshops.Sum(w => w.ManufacturingTime);
                    var labelTotalTime = new Label
                    {
                        Text = $"Общее время изготовления: {Math.Ceiling(totalTime)} ч",
                        Font = new Font("Candara", 11F, FontStyle.Bold),
                        Location = new Point(20, 420),
                        Size = new Size(300, 25),
                        ForeColor = ColorTranslator.FromHtml("#355CBD")
                    };
                    this.Controls.Add(labelTotalTime);
                }

                this.Text = $"Цехи для производства - {selectedProduct.ProductName} ({workshops.Count} цехов)";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке списка цехов: {ex.Message}", 
                              "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Обработчик нажатия кнопки "Назад"
        /// </summary>
        private void ButtonBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Обработчик события загрузки формы
        /// </summary>
        private void WorkshopListForm_Load(object sender, EventArgs e)
        {
            // Дополнительная инициализация при необходимости
        }
    }
} 