using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace Comfort
{
    // Форма для расчёта необходимого количества сырья
    public partial class RawMaterialsForm : Form
    {
        // Конструктор: инициализирует компоненты и загружает начальные данные
        public RawMaterialsForm()
        {
            InitializeComponent();
            LoadData();
        }

        // Загружает типы продуктов и материалы в комбобоксы из базы данных
        private void LoadData()
        {
            // Если нет соединения с БД, пропускаем загрузку
            if (!Program.DbAvailable)
                return;
            string connStr = ConfigurationManager.ConnectionStrings["ComfortDB"].ConnectionString;
            using (var conn = new SqlConnection(connStr))
            {
                conn.Open();
                var dtTypes = new DataTable();
                using (var da = new SqlDataAdapter("SELECT ProductTypeID, ProductTypeName FROM ProductTypes", conn))
                    da.Fill(dtTypes);
                cmbProductType.DataSource = dtTypes;
                cmbProductType.ValueMember = "ProductTypeID";
                cmbProductType.DisplayMember = "ProductTypeName";

                var dtMaterials = new DataTable();
                using (var da = new SqlDataAdapter("SELECT MaterialID, MaterialName FROM Materials", conn))
                    da.Fill(dtMaterials);
                cmbMaterial.DataSource = dtMaterials;
                cmbMaterial.ValueMember = "MaterialID";
                cmbMaterial.DisplayMember = "MaterialName";
            }
        }

        // Обрабатывает нажатие 'Рассчитать': выполняет вычисление и отображает результат
        private void btnCalculate_Click(object sender, EventArgs e)
        {
            // Если нет соединения с БД, информируем и выходим
            if (!Program.DbAvailable)
            {
                lblResult.Text = "Невозможно рассчитать: база данных недоступна.";
                return;
            }
            try
            {
                int productTypeId = Convert.ToInt32(cmbProductType.SelectedValue);
                int materialTypeId = Convert.ToInt32(cmbMaterial.SelectedValue);
                int quantity = (int)nudQuantity.Value;
                double length = (double)nudLength.Value;
                double width = (double)nudWidth.Value;

                int result = RawMaterialsCalculator.CalculateRawMaterials(
                    productTypeId, materialTypeId, quantity, length, width);
                if (result < 0)
                    MessageBox.Show("Некорректные входные данные.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                else
                    lblResult.Text = $"Необходимое количество сырья: {result}";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при расчёте сырья: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Обрабатывает нажатие 'Закрыть': закрывает форму
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
} 
