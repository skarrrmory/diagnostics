string query = @"
    SELECT w.WorkshopName AS [Название цеха],
           w.StaffCount   AS [Количество работников],
    pw.ManufacturingTime AS [Время изготовления]
    FROM ProductWorkshops pw
    INNER JOIN Workshops w ON pw.WorkshopID = w.WorkshopID
    WHERE pw.ProductID = @pid"; 