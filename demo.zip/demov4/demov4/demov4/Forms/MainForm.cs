using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using demov4.Data;
using demov4.Models;

namespace demov4.Forms
{
    /// <summary>
    /// Главная форма приложения для отображения списка продукции
    /// </summary>
    public partial class MainForm : Form
    {
        private DatabaseHelper databaseHelper;
        private List<Product> products;
        private DataGridView dataGridViewProducts;
        private Button buttonAdd;
        private PictureBox pictureBoxLogo;

        public MainForm()
        {
            InitializeComponent();
            databaseHelper = new DatabaseHelper();
            InitializeCustomComponents();
            LoadProducts();
        }

        /// <summary>
        /// Инициализация пользовательских компонентов
        /// </summary>
        private void InitializeCustomComponents()
        {
            // Настройка формы
            this.Text = "Система управления продукцией - Комфорт";
            this.Size = new Size(1200, 700);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.White;
            this.Font = new Font("Candara", 10F);

            // Логотип компании
            pictureBoxLogo = new PictureBox
            {
                Size = new Size(100, 100),
                Location = new Point(20, 20),
                SizeMode = PictureBoxSizeMode.Zoom,
                BackColor = ColorTranslator.FromHtml("#D2DFFF"),
                BorderStyle = BorderStyle.FixedSingle
            };

            // Создание заголовка
            var labelTitle = new Label
            {
                Text = "Список продукции",
                Font = new Font("Candara", 20F, FontStyle.Bold),
                Location = new Point(140, 55),
                Size = new Size(300, 30),
                ForeColor = ColorTranslator.FromHtml("#355CBD")
            };

            // Кнопка добавления
            buttonAdd = new Button
            {
                Text = "Добавить продукт",
                Font = new Font("Candara", 12F),
                Size = new Size(160, 40),
                Location = new Point(20, 135),
                BackColor = ColorTranslator.FromHtml("#355CBD"),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand
            };
            buttonAdd.FlatAppearance.BorderSize = 0;
            buttonAdd.Click += ButtonAdd_Click;

            // Отображение продукции
            dataGridViewProducts = new DataGridView
            {
                Location = new Point(20, 190),
                Size = new Size(1140, 450),
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                Font = new Font("Candara", 9F)
            };

            // Настройка стиля
            dataGridViewProducts.EnableHeadersVisualStyles = false;
            dataGridViewProducts.ColumnHeadersDefaultCellStyle.BackColor = ColorTranslator.FromHtml("#D2DFFF");
            dataGridViewProducts.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black;
            dataGridViewProducts.ColumnHeadersDefaultCellStyle.Font = new Font("Candara", 10F, FontStyle.Bold);
            dataGridViewProducts.ColumnHeadersHeight = 35;

            dataGridViewProducts.DefaultCellStyle.SelectionBackColor = ColorTranslator.FromHtml("#355CBD");
            dataGridViewProducts.DefaultCellStyle.SelectionForeColor = Color.White;
            dataGridViewProducts.AlternatingRowsDefaultCellStyle.BackColor = ColorTranslator.FromHtml("#F8F9FF");

            dataGridViewProducts.CellDoubleClick += DataGridViewProducts_CellDoubleClick;

            // Добавление компонентов на форму
            this.Controls.Add(pictureBoxLogo);
            this.Controls.Add(labelTitle);
            this.Controls.Add(buttonAdd);
            this.Controls.Add(dataGridViewProducts);
        }

        /// <summary>
        /// Загрузка списка продукции из базы данных
        /// </summary>
        private void LoadProducts()
        {
            try
            {
                // Проверка подключения к базе данных
                if (!databaseHelper.TestConnection())
                {
                    MessageBox.Show("Не удаётся подключиться к базе данных. Проверьте настройки подключения.", 
                                  "Ошибка подключения!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                products = databaseHelper.GetAllProducts();
                
                // Настройка колонок
                dataGridViewProducts.DataSource = null;
                dataGridViewProducts.Columns.Clear();

                dataGridViewProducts.Columns.Add(new DataGridViewTextBoxColumn
                {
                    Name = "Article",
                    HeaderText = "Артикул",
                    DataPropertyName = "Article",
                    Width = 100
                });

                dataGridViewProducts.Columns.Add(new DataGridViewTextBoxColumn
                {
                    Name = "ProductType",
                    HeaderText = "Тип продукции",
                    DataPropertyName = "ProductType",
                    Width = 120
                });

                dataGridViewProducts.Columns.Add(new DataGridViewTextBoxColumn
                {
                    Name = "ProductName",
                    HeaderText = "Наименование",
                    DataPropertyName = "ProductName",
                    Width = 300
                });

                dataGridViewProducts.Columns.Add(new DataGridViewTextBoxColumn
                {
                    Name = "FormattedCost",
                    HeaderText = "Мин. стоимость для партнёра",
                    DataPropertyName = "FormattedCost",
                    Width = 180
                });

                dataGridViewProducts.Columns.Add(new DataGridViewTextBoxColumn
                {
                    Name = "MainMaterial",
                    HeaderText = "Основной материал",
                    DataPropertyName = "MainMaterial",
                    Width = 200
                });

                dataGridViewProducts.Columns.Add(new DataGridViewTextBoxColumn
                {
                    Name = "FormattedManufacturingTime",
                    HeaderText = "Время изготовления",
                    DataPropertyName = "FormattedManufacturingTime",
                    Width = 140
                });

                dataGridViewProducts.DataSource = products;

                // Обновление заголовка с количеством записей
                this.Text = $"Система управления продукцией - Комфорт ({products.Count} товаров)";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}", 
                              "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Обработчик нажатия кнопки добавления
        /// </summary>
        private void ButtonAdd_Click(object sender, EventArgs e)
        {
            try
            {
                var editForm = new ProductEditForm();
                if (editForm.ShowDialog() == DialogResult.OK)
                {
                    LoadProducts(); // Обновление список после добавления
                    MessageBox.Show("Продукт успешно добавлен!", "Успех", 
                                  MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении продукта: {ex.Message}", 
                              "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Обработчик двойного клика
        /// </summary>
        private void DataGridViewProducts_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < products.Count)
            {
                try
                {
                    var selectedProduct = products[e.RowIndex];
                    
                    // Создание контекстное меню для выбора действия
                    var contextMenu = new ContextMenuStrip();
                    
                    var editMenuItem = new ToolStripMenuItem("Редактировать продукт");
                    editMenuItem.Click += (s, args) => EditProduct(selectedProduct);
                    
                    var workshopsMenuItem = new ToolStripMenuItem("Просмотр цехов");
                    workshopsMenuItem.Click += (s, args) => ShowWorkshops(selectedProduct);
                    
                    contextMenu.Items.Add(editMenuItem);
                    contextMenu.Items.Add(workshopsMenuItem);
                    
                    // Показ меню в позиции курсора
                    contextMenu.Show(Cursor.Position);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при обработке выбора: {ex.Message}", 
                                  "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        /// <summary>
        /// Редактирование выбранного продукта
        /// </summary>
        private void EditProduct(Product product)
        {
            try
            {
                var editForm = new ProductEditForm(product.ProductId);
                if (editForm.ShowDialog() == DialogResult.OK)
                {
                    LoadProducts(); // Обновление списка после редактирования
                    MessageBox.Show("Продукт успешно обновлён!", "Успех!", 
                                  MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при редактировании продукта: {ex.Message}", 
                              "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Показ списка цехов для выбранного продукта
        /// </summary>
        private void ShowWorkshops(Product product)
        {
            try
            {
                var workshopForm = new WorkshopListForm(product);
                workshopForm.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при отображении цехов: {ex.Message}", 
                              "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Обработчик события загрузки формы
        /// </summary>
        private void MainForm_Load(object sender, EventArgs e)
        {
            // Дополнительная инициализация при необходимости
        }
    }
} 